package model;

public class InvalidDateInput extends Exception {
	public InvalidDateInput(String message) {
		super(message);
	}
}
