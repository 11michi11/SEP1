package model;

public class MemberAlreadyPaidException extends Exception {

	public MemberAlreadyPaidException(String message) {
		super(message);
	}

}
