package test;

import java.util.Arrays;

import controler.VIAController;
import model.Category;
import model.EventList;
import model.Member;
import model.MemberList;
import model.MyDate;

public class SearchEngineTest
{

   public static void main(String[] args)
   {
     /* MemberList members = new MemberList();
      
      MyDate date1 = new MyDate(5, 5, 2015,0,0);
      MyDate date2 = new MyDate(2, 4, 2010,0,0);
      MyDate date3 = new MyDate(16, 3, 2008,0,0);
      MyDate date4 = new MyDate(10, 10, 2000,0,0);
      Member member1 = new Member("Daniela", "Kamtjatka 44", 489218451, "daniela@gmail.com", date1);
      Member member2 = new Member("Daniel", "Kamgade 55", 419218448, "daniel@gmail.com", date2);
      Member member3 = new Member("Reme", "Aamliegdae 94", 449218132, "reme@gmail.com", date3);
      Member member4 = new Member("Remo", "Ostergade 15", 458184411, "remo@gmail.com", date4);
      
      members.addMember(member1);
      members.addMember(member2);
      members.addMember(member3);
      members.addMember(member4);
     
     */
   }

}
