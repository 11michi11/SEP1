To run this application, you have to import whole SDJ1 folder as project
or run this command in command line(while being in SDJ1 folder):

java -classpath bin/ controler.VIAController

Files are generated in root folder of project.